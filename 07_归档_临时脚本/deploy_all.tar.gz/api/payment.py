import time
import hashlib
import requests
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel
from api.auth import auth_required
from models.db import create_order, pay_order, get_user
from config import PLANS, POINTS_PER_YUAN, SECRET_KEY

router = APIRouter(prefix="/api/pay", tags=["payment"])

PAY_URL = ""
PAY_PID = ""
PAY_KEY = ""
PAY_TYPE = "epay"


def init_payment(url: str, pid: str, key: str, ptype: str = "epay"):
    global PAY_URL, PAY_PID, PAY_KEY, PAY_TYPE
    PAY_URL = url.rstrip("/")
    PAY_PID = pid
    PAY_KEY = key
    PAY_TYPE = ptype


class CreateOrderReq(BaseModel):
    plan_id: str


@router.post("/create")
def create_payment(req: CreateOrderReq, user: dict = Depends(auth_required)):
    plan = next((p for p in PLANS if p["id"] == req.plan_id), None)
    if not plan:
        raise HTTPException(400, "套餐不存在")
    oid = create_order(user["id"], plan["id"], plan["price"], plan["points"])
    if not PAY_URL:
        pay_order(oid, f"manual_{oid}")
        return {"order_id": oid, "status": "paid", "msg": "支付未配置，已自动到账（测试模式）"}

    if PAY_TYPE == "xunhu":
        return _create_xunhu(oid, plan)
    return _create_epay(oid, plan)


def _create_epay(oid: int, plan: dict) -> dict:
    notify_url = f"{PAY_URL}/api/pay/notify"
    return_url = f"{PAY_URL}/api/pay/return"
    params = {
        "pid": PAY_PID,
        "type": "wxpay",
        "out_trade_no": str(oid),
        "notify_url": notify_url,
        "return_url": return_url,
        "name": f"AiForge-{plan['name']}",
        "money": str(plan["price"]),
    }
    sign_str = "".join(f"{k}={v}&" for k, v in sorted(params.items()) if v) + PAY_KEY
    params["sign"] = hashlib.md5(sign_str.encode()).hexdigest()
    params["sign_type"] = "MD5"
    query = "&".join(f"{k}={v}" for k, v in params.items())
    pay_url = f"{PAY_URL}/submit.php?{query}"
    return {"order_id": oid, "pay_url": pay_url, "status": "pending"}


def _create_xunhu(oid: int, plan: dict) -> dict:
    notify_url = f"{PAY_URL}/api/pay/notify"
    return_url = f"{PAY_URL}/api/pay/return"
    params = {
        "appid": PAY_PID,
        "out_trade_no": str(oid),
        "total_fee": str(plan["price"]),
        "notify_url": notify_url,
        "return_url": return_url,
        "title": f"AiForge-{plan['name']}",
        "time": str(int(time.time())),
    }
    sign_str = "&".join(f"{k}={v}" for k, v in sorted(params.items()) if v) + PAY_KEY
    params["hash"] = hashlib.md5(sign_str.encode()).hexdigest()
    pay_url = f"https://api.xunhupay.com/payment/do.html?{ '&'.join(f'{k}={v}' for k, v in params.items())}"
    return {"order_id": oid, "pay_url": pay_url, "status": "pending"}


@router.api_route("/notify", methods=["GET", "POST"])
def notify(request: Request):
    if request.method == "POST":
        form = dict(request.query_params)
        body = dict(request.query_params)
        form.update(body)
    else:
        form = dict(request.query_params)

    sign = form.pop("sign", form.pop("hash", ""))
    form.pop("sign_type", None)
    trade_no = form.get("trade_no", form.get("transaction_id", ""))
    out_trade_no = form.get("out_trade_no", "")

    sign_str = "".join(f"{k}={v}" for k, v in sorted(form.items()) if v and k not in ("sign", "hash", "sign_type")) + PAY_KEY
    expected = hashlib.md5(sign_str.encode()).hexdigest()

    if sign != expected:
        return "sign error"

    trade_status = form.get("trade_status", form.get("status", ""))
    if trade_status in ("TRADE_SUCCESS", "OD"):
        try:
            pay_order(int(out_trade_no), trade_no)
        except Exception:
            pass
    return "success"


@router.get("/return")
def pay_return():
    return {"msg": "支付完成，请返回查看余额"}


@router.get("/order/{oid}")
def order_status(oid: int, user: dict = Depends(auth_required)):
    from models.db import _get_conn
    conn = _get_conn()
    row = conn.execute("SELECT * FROM orders WHERE id=? AND user_id=?", (oid, user["id"])).fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "订单不存在")
    return dict(row)
