import os
import threading
import time
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from api.auth import auth_required
from models.db import deduct_points, create_task, update_task, get_user_tasks
from core.proxy import OiioiiProxy
from config import OIIOII_API

router = APIRouter(prefix="/api/gen", tags=["generate"])
proxy = OiioiiProxy(OIIOII_API)

_task_callbacks = {}


class ImageReq(BaseModel):
    prompt: str
    model: str = "Flux Dev"
    ratio: str = "1:1"
    resolution: str = "1K"
    reference_images: list = []


class VideoReq(BaseModel):
    prompt: str
    model: str = "Vidu Q2"
    ratio: str = "16:9"
    resolution: str = "720p"
    duration: int = 5
    reference_images: list = []
    reference_video: str = ""


def _calc_image_cost(model: str, resolution: str) -> int:
    if resolution in ("4K", "4k"):
        return 20
    if resolution in ("2K", "1080p"):
        return 10
    return 5


def _calc_video_cost(model: str, duration: int, resolution: str) -> int:
    # 以10秒1080p为基准100积分
    base = 100
    if "Kling" in model:
        base = 75
    
    # 分辨率系数
    res_scale = 1.0
    if resolution == "720p":
        res_scale = 0.7
    elif resolution in ("1080p", "2K"):
        res_scale = 1.0
    elif resolution in ("4K", "4k"):
        res_scale = 1.5  # 按需
    
    # 时长系数
    duration_scale = {4: 0.4, 5: 0.5, 6: 0.6, 8: 0.8, 10: 1.0, 15: 1.5, 20: 2.0}.get(duration, 1.0)
    
    cost = int(base * res_scale * duration_scale)
    return cost


def _poll_oiioii(task_id: int, aiforge_task_id: int, uid: int, cost: int):
    from models.db import add_points
    start = time.time()
    while time.time() - start < 600:
        result = proxy.get_task(task_id)
        if result.get("error"):
            time.sleep(5)
            continue
        status = result.get("status", "")
        if status == "completed":
            file_url = f"/api/gen/file/{task_id}"
            update_task(aiforge_task_id, "completed", file_url)
            return
        elif status == "failed":
            update_task(aiforge_task_id, "failed", "")
            add_points(uid, cost, f"任务失败退还-#{aiforge_task_id}")
            return
        time.sleep(5)
    update_task(aiforge_task_id, "timeout", "")
    add_points(uid, cost, f"任务超时退还-#{aiforge_task_id}")


@router.get("/models")
def get_models():
    return proxy.get_models()


@router.post("/image")
def generate_image(req: ImageReq, user: dict = Depends(auth_required)):
    cost = _calc_image_cost(req.model, req.resolution)
    if not deduct_points(user["id"], cost, f"生成图片-{req.model}"):
        raise HTTPException(402, "积分不足")
    result = proxy.generate_image(req.prompt, req.model, req.ratio, req.resolution, req.reference_images)
    if "error" in result:
        from models.db import add_points
        add_points(user["id"], cost, f"提交失败退还-{req.model}")
        raise HTTPException(500, result["error"])
    oiioii_id = result.get("task_id", 0)
    af_id = create_task(user["id"], "image", req.model, req.prompt, cost, oiioii_id)
    t = threading.Thread(target=_poll_oiioii, args=(oiioii_id, af_id, user["id"], cost), daemon=True)
    t.start()
    return {"task_id": af_id, "oiioii_task_id": oiioii_id, "cost": cost, "status": "running"}


@router.post("/video")
def generate_video(req: VideoReq, user: dict = Depends(auth_required)):
    cost = _calc_video_cost(req.model, req.duration, req.resolution)
    if not deduct_points(user["id"], cost, f"生成视频-{req.model}"):
        raise HTTPException(402, "积分不足")
    result = proxy.generate_video(req.prompt, req.model, req.ratio, req.resolution,
                                  req.duration, req.reference_images, req.reference_video)
    if "error" in result:
        from models.db import add_points
        add_points(user["id"], cost, f"提交失败退还-{req.model}")
        raise HTTPException(500, result["error"])
    oiioii_id = result.get("task_id", 0)
    af_id = create_task(user["id"], "video", req.model, req.prompt, cost, oiioii_id)
    t = threading.Thread(target=_poll_oiioii, args=(oiioii_id, af_id, user["id"], cost), daemon=True)
    t.start()
    return {"task_id": af_id, "oiioii_task_id": oiioii_id, "cost": cost, "status": "running"}


@router.get("/task/{task_id}")
def get_task(task_id: int, user: dict = Depends(auth_required)):
    from models.db import _get_conn
    conn = _get_conn()
    row = conn.execute("SELECT * FROM tasks WHERE id=? AND user_id=?", (task_id, user["id"])).fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "任务不存在")
    return dict(row)


@router.get("/tasks")
def list_tasks(user: dict = Depends(auth_required), limit: int = 50):
    return get_user_tasks(user["id"], limit)


@router.delete("/task/{task_id}")
def delete_task(task_id: int, user: dict = Depends(auth_required)):
    from models.db import _get_conn
    conn = _get_conn()
    row = conn.execute("SELECT id, status, points_cost FROM tasks WHERE id=? AND user_id=?", (task_id, user["id"])).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "任务不存在")
    if row["status"] == "running":
        conn.close()
        raise HTTPException(400, "运行中的任务不能删除")
    conn.execute("DELETE FROM tasks WHERE id=? AND user_id=?", (task_id, user["id"]))
    conn.commit()
    conn.close()
    return {"ok": True}


@router.post("/upload_ref")
async def upload_ref(file: UploadFile = File(...), user: dict = Depends(auth_required)):
    content = await file.read()
    result = proxy.upload_ref(content, file.filename or "img.png")
    if "error" in result:
        raise HTTPException(500, result["error"])
    return result


@router.post("/upload_video_ref")
async def upload_video_ref(file: UploadFile = File(...), user: dict = Depends(auth_required)):
    content = await file.read()
    result = proxy.upload_video_ref(content, file.filename or "video.mp4")
    if "error" in result:
        raise HTTPException(500, result["error"])
    return result


@router.get("/file/{oiioii_task_id}")
def proxy_file(oiioii_task_id: int, token: str = ""):
    import jwt
    from config import SECRET_KEY, JWT_ALGORITHM
    uid = None
    if token:
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[JWT_ALGORITHM])
            uid = payload.get("uid")
        except Exception:
            pass
    if uid is None:
        raise HTTPException(401, "未登录")
    from models.db import _get_conn
    conn = _get_conn()
    row = conn.execute(
        "SELECT oiioii_task_id, task_type FROM tasks WHERE oiioii_task_id=? AND user_id=?",
        (oiioii_task_id, uid)
    ).fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "文件不存在")
    import requests as req
    try:
        r = req.get(f"{OIIOII_API}/api/task/{oiioii_task_id}/download", stream=True, timeout=60)
        if r.status_code != 200:
            raise HTTPException(502, "上游文件获取失败")
        content_type = r.headers.get("content-type", "application/octet-stream")
        filename = ""
        cd = r.headers.get("content-disposition", "")
        if "filename=" in cd:
            filename = cd.split("filename=")[-1].strip('"')
        if not filename:
            ext = ".mp4" if row["task_type"] == "video" else ".png"
            filename = f"aiforge_{oiioii_task_id}{ext}"
        def _stream():
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    yield chunk
        return StreamingResponse(
            _stream(),
            media_type=content_type,
            headers={"Content-Disposition": f'inline; filename="{filename}"'},
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"文件代理失败: {e}")
